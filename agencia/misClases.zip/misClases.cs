﻿using System;
using System.Windows.Forms;

namespace agencia
{
    class Autobus : Vehiculo
    {
        public double CantidadKmFinal { get; set; }
        public double CantidadKmInicial { get; set; }
        public double PrecioKilometro { get; set; }

        public override void DevolverVehiculo()
        {
            Alquilado = false;

            ImporteRenta = (CantidadKmFinal - CantidadKmInicial) * PrecioKilometro;

            MessageBox.Show($"AUTOBUS" +
                            $"Placas: {Placas}" +
                            $"Alquilado: {Alquilado}" +
                            $"Importe a pagar: {ImporteRenta}");
        }

        public override void RentarVehiculo()
        {
            Alquilado = true;

            MessageBox.Show($"AUTOBUS" +
                            $"Placas: {Placas}" +
                            $"Alquilado: {Alquilado}");
        }
    }

    class Tractor : Vehiculo
    {
        public DateTime FechaDevolucion { get; set; }
        public DateTime FechaRenta { get; set; }
        public double PrecioDia { get; set; }

        public override void DevolverVehiculo()
        {
            Alquilado = false;

            ImporteRenta = PrecioDia * (FechaDevolucion - FechaRenta).TotalDays;

            if (DateTime.Now > FechaDevolucion)
            {
                MessageBox.Show("No se ha devuelto en la fecha establecia, se aplicará un cargo del 25%");
                ImporteRenta = (ImporteRenta * .25) + ImporteRenta;
            }

            MessageBox.Show($"TRACTOR" +
                            $"Placas: {Placas}" +
                            $"Alquilado: {Alquilado}" +
                            $"Importe a pagar: {ImporteRenta}");
        }

        public override void RentarVehiculo()
        {
            Alquilado = true;

            MessageBox.Show($"TRACTOR" +
                            $"Placas: {Placas}" +
                            $"Alquilado: {Alquilado}");
        }
    }

    abstract class Vehiculo
    {
        public bool Alquilado { get; set; }
        public double ImporteRenta { get; set; }
        public string Placas { get; set; }

        public abstract void DevolverVehiculo();

        public abstract void RentarVehiculo();
    }
}